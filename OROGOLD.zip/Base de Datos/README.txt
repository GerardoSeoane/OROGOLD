Se incluye el archivo .bak para poder restaurar la base de datos
en SQL Server y tambien un archivo txt con los comandos de creación
de la base, la tabla y los stored procedures.