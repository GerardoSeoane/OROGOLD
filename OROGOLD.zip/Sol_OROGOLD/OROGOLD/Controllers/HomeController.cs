﻿using OROGOLDCapaBussines;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OROGOLD.Controllers
{
    public class HomeController : Controller
    {
        Validaciones accion = new Validaciones();
        // GET: Home
        public ActionResult Principal()
        {
            return View();
        }

        public JsonResult AgregarReservacion(Reservacion R)
        {
            try
            {
                accion.CitasRepetidas(R);
                accion.AgregarReservacion(R);
                return Json(new { mensaje = "ok" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception Error)
            {
                return Json(new { mensaje = Error.Message }, JsonRequestBehavior.AllowGet);
            }
        }

    }
}