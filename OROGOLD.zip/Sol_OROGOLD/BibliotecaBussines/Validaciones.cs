﻿using OROGOLDCapaSQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;


namespace OROGOLDCapaBussines
{
    public class Validaciones
    {
        Sentencias accion = new Sentencias();
        
        public void AgregarReservacion(Reservacion R)
        {
            int FilasAfectadas = accion.AgregarReservacion(R.Nombre, R.Email, R.Telefono);
            if (FilasAfectadas != 1)
            {
                throw new ApplicationException("Error al Agregar");
            }
        }

        public void CitasRepetidas(Reservacion R)
        {
            DataTable Repetidos = accion.CitasRepetidas(R.Email);
            if (Repetidos.Rows.Count>0)
            {
                throw new ApplicationException("Ya Existe Cita");
            }
        }
    }
}
