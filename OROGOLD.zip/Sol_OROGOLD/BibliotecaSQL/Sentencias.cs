﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace OROGOLDCapaSQL
{
    public class Sentencias
    {
        SqlConnection conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["sql"].ConnectionString);

        public int AgregarReservacion(string Nombre, string Email, string Telefono)
        {
            int FilasAfectadas = 0;
            string Nombre1 = Nombre.Substring(0, 1).ToUpper() + Nombre.Substring(1).ToLower();
            string Email1 = Email.ToLower();
            SqlCommand comando = new SqlCommand("spAgregarOROGOLD",conexion);
            comando.CommandType = CommandType.StoredProcedure;
          
            comando.Parameters.AddWithValue("@Nombre", Nombre1);
            comando.Parameters.AddWithValue("@Email", Email1);
            comando.Parameters.AddWithValue("@Telefono", Telefono);

            try
            {
                conexion.Open();
                FilasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();
                return FilasAfectadas;

            }
            catch (Exception)
            {
                conexion.Close();
                throw;
            }
        }


        public DataTable CitasRepetidas(string Email)
        {
            SqlCommand comando = new SqlCommand("spRepetidasOROGOLD", conexion);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@Email", Email);

            DataTable fila = new DataTable();
            SqlDataAdapter ObtenerPersona = new SqlDataAdapter(comando);
            ObtenerPersona.Fill(fila);
            return fila;
        }

    }
}
